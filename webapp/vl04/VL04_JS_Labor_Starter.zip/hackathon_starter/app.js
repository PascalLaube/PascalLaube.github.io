// Campus Hackathon · JS-Labor VL 4
// Starten nur über einen Server, sonst blockiert der Browser das Skript:
//   python -m http.server 8000   →   http://localhost:8000
// Eure Aufgaben stehen bei den TODO-Kommentaren.

console.log("app.js ist geladen");

// ── Teil B: Programm laden und anzeigen ───────────────────────────
const liste = document.querySelector("#programm-liste");
const status = document.querySelector("#programm-status");

async function ladeProgramm() {
  try {
    // TODO B1: Holt "programm.json" mit fetch und wartet mit await auf die Antwort.
    // TODO B2: Ist antwort.ok falsch, werft einen Error mit dem Statuscode.
    // TODO B3: Lest den Body mit await antwort.json() und hängt für jeden
    //          Programmpunkt karte(punkt) an die liste an. Danach status entfernen.
  } catch (fehler) {
    status.textContent = `Programm konnte nicht geladen werden (${fehler.message}).`;
    status.classList.add("fehler");
  }
}

// Fertig: baut aus { zeit, titel, text } eine Karte wie in VL 2.
function karte({ zeit, titel, text }) {
  const li = document.createElement("li");
  const article = document.createElement("article");
  article.className = "card";

  const h3 = document.createElement("h3");
  const time = document.createElement("time");
  time.textContent = zeit;
  h3.append(time, ` · ${titel}`);

  const p = document.createElement("p");
  p.textContent = text;

  article.append(h3, p);
  li.append(article);
  return li;
}

ladeProgramm();

// ── Teil C: Anmeldung prüfen, ohne die Seite neu zu laden ─────────
const form = document.querySelector("#anmeldung-form");
const email = document.querySelector("#email");
const emailFehler = document.querySelector("#email-fehler");

function pruefeEmail() {
  // TODO C1: ok ist true, wenn email.value (ohne Leerzeichen) auf
  //          "@htwg-konstanz.de" endet.
  const ok = true;
  email.classList.toggle("ungueltig", !ok);
  emailFehler.textContent = ok ? "" : "Bitte eure HTWG-Adresse verwenden.";
  return ok;
}

// TODO C2: Ruft pruefeEmail bei jedem "input"-Event auf dem E-Mail-Feld auf.

form.addEventListener("submit", (event) => {
  // TODO C3: Verhindert, dass der Browser das Formular abschickt und neu lädt.
  const name = form.elements.name.value.trim();
  if (!name || !pruefeEmail()) {
    return;
  }
  // TODO C4: Ersetzt das Formular durch einen Absatz mit der Klasse
  //          "bestaetigung" und dem Text "Danke, <Name>! Wir melden uns per Mail."
  //          Nutzt textContent, nicht innerHTML. Warum?
});
