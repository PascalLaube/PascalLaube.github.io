# Übung VL 02 · Recap HTML und CSS

**Web-Applikationen · WS 2026/27 · Donnerstag, 08.10.2026, 09:45–11:15, F/033**

Teil A und B dürft ihr gern zu zweit bearbeiten. Das Semesterprojekt macht ihr in Einzelarbeit.

---

## Teil A · Semantisches Refactoring (ca. 30 Minuten)

**Datei:** `uebung_semantisches_refactoring.html`

Die Seite ist ein kleiner Blog, gebaut aus lauter `div` und `span`. Visuell sieht sie normal aus, aber sie hat keine Bedeutung. Genau wie Stufe 1 unserer Hackathon-Seite.

1. Öffnet die Datei im Browser und im Editor.
2. Ersetzt jedes `div` und `span` durch das passende Element. Nutzt mindestens `header`, `nav`, `main`, `article`, `h1`, `h2`, `p`, `figure`, `figcaption`, `time`, `ul`, `li`, `footer`.
3. Ergänzt, was fehlt: `lang`, Alt-Text, eine saubere Überschriften-Hierarchie.
4. Die Seite soll danach **gleich aussehen**. Passt dafür die CSS-Selektoren an.

**Selbstcheck:** Lasst Lighthouse (DevTools → Lighthouse → Accessibility) über die alte und die neue Version laufen. Wie verändert sich der Wert?

---

## Teil B · CSS Escape Room (ca. 50 Minuten)

**Datei:** `css_escape_room.html` im Browser öffnen.

Acht Rätsel, jedes mit einer kaputten Vorschau. Schreibt echtes CSS in das Eingabefeld, bis die Prüfung grün wird.

| Rätsel | Thema | Kapitel im Skript |
|---|---|---|
| 1 | Box-Modell reparieren | Das Box-Modell |
| 2 | Spezifitäts-Duell | Welche Regel gewinnt? |
| 3 | Perfekte Zentrierung | Flexbox oder Grid? |
| 4 | Navbar horizontal | Flexbox oder Grid? |
| 5 | Grid: zwei Spalten | Flexbox oder Grid? |
| 6 | Responsive Cards | Responsive mit Mobile-First |
| 7 | CSS-Variablen und Dark Mode | Design-Token mit CSS-Variablen |
| 8 | Typografie mit rem | Bonus, nicht im Skript |

**Tipp:** Wenn ihr hängt, untersucht die Vorschau mit den DevTools. Durchgestrichene Regeln im Styles-Panel zeigen euch, wer verloren hat.

---

## Teil C · Projektstart (ca. 10 Minuten)

1. Notiert eine erste Projektidee in zwei, drei Sätzen: Was kann die App, für wen ist sie?
2. Legt euer Git-Repository an.

Die Anforderungen an Meilenstein M1 findet ihr in Moodle.
